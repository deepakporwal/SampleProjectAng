import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-samplebs',
  templateUrl: './samplebs.component.html',
  styleUrls: ['./samplebs.component.css']
})
export class SamplebsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
